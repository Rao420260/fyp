import { Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'

import RouteEffects from './components/RouteEffects'
import Landing from './pages/Landing'
import Login from './pages/Login'
import Signup from './pages/Signup'
import ConnectAccounts from './pages/ConnectAccounts'
import Chatbot from './pages/Chatbot'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <>
      <Toaster position="top-right" />
      <RouteEffects />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/connect" element={<ConnectAccounts />} />
        <Route path="/assistant" element={<Chatbot />} />
        {/* Koi bhi galat link yahan aayega */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  )
}